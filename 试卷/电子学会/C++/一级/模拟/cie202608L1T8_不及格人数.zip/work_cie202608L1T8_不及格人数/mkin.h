#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

// ═══════════════════════════════════════════════════════════════════
// 总测试点数量 & Subtask 分组配置
// ═══════════════════════════════════════════════════════════════════
const int TEST_CASES = 25;

struct SubtaskDef {
    int id, start, end;
};
const SubtaskDef SUBTASKS[] = {
    {0, 1, 2},    // 样例
    {1, 3, 8},    // 小规模 + 特殊性质
    {2, 9, 11},   // Hack 数据
    {3, 12, 20},  // 中大规模
    {4, 21, 25},  // 随机回归
};
const int SUBTASK_COUNT = sizeof(SUBTASKS) / sizeof(SUBTASKS[0]);

/**
 * 不及格人数 - 测试数据生成
 * 输入：n（1≤n≤1000），第二行 n 个整数（0≤x≤100）
 * 输出：成绩小于 60 的人数
 */

void test(int case_num, ofstream& fout)
{
    // ============================================================
    // Subtask 0: 样例数据 — case 1-2
    // ============================================================
    if (case_num == 1) {
        fout << 5 << endl;
        fout << "85 42 90 58 100" << endl;
    }
    else if (case_num == 2) {
        fout << 3 << endl;
        fout << "60 70 80" << endl;
    }
    // ============================================================
    // Subtask 1: 小规模 + 特殊性质 — case 3-8
    // ============================================================
    else if (case_num == 3) {
        // 最小 n=1，及格
        fout << 1 << endl;
        fout << 60 << endl;
    }
    else if (case_num == 4) {
        // 小规模随机 n=8
        fout << 8 << endl;
        for (int i = 0; i < 8; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
    else if (case_num == 5) {
        // 特殊：全不及格
        fout << 6 << endl;
        fout << "10 20 30 40 50 59" << endl;
    }
    else if (case_num == 6) {
        // 特殊：全及格
        fout << 6 << endl;
        fout << "60 70 80 90 100 61" << endl;
    }
    else if (case_num == 7) {
        // 特殊：边界 59 与 60
        fout << 4 << endl;
        fout << "59 60 58 61" << endl;
    }
    else if (case_num == 8) {
        // 特殊：只有一个是 0
        fout << 5 << endl;
        fout << "0 100 100 100 100" << endl;
    }
    // ============================================================
    // Subtask 2: Hack 数据 — case 9-11
    // ============================================================
    else if (case_num == 9) {
        // Hack：n=1 且恰为 60（边界：60 不算不及格）
        fout << 1 << endl;
        fout << 60 << endl;
    }
    else if (case_num == 10) {
        // Hack：一半 0 一半 60（边界值 60 混入）
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << (i < 500 ? 0 : 60);
        }
        fout << endl;
    }
    else if (case_num == 11) {
        // Hack：999 个 100 + 末尾 1 个 59（末位 59 拦 off-by-one 与 x<59）
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << (i < 999 ? 100 : 59);
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 3: 中大规模 — case 12-20
    // ============================================================
    else if (case_num >= 12 && case_num <= 15) {
        // 中规模随机 n≈100~500
        int n = rand() % 401 + 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 18) {
        // 大规模 n=1000
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
    else if (case_num == 19) {
        // 半及格半不及格
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << (i % 2 == 0 ? 30 : 90);
        }
        fout << endl;
    }
    else if (case_num == 20) {
        // 大部分及格
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 40 + 60;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 4: 随机回归 — case 21-25
    // ============================================================
    else {
        int n = rand() % 1000 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
}

#endif
