#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

// ═══════════════════════════════════════════════════════════════════
// 总测试点数量 & Subtask 分组配置
// ═══════════════════════════════════════════════════════════════════
const int TEST_CASES = 25;

struct SubtaskDef {
    int id, start, end;
};
const SubtaskDef SUBTASKS[] = {
    {0, 1, 3},    // 样例（题面 3 个样例）
    {1, 4, 8},    // 小规模 + 特殊性质
    {2, 9, 11},   // Hack 数据
    {3, 12, 20},  // 中大规模
    {4, 21, 25},  // 随机回归
};
const int SUBTASK_COUNT = sizeof(SUBTASKS) / sizeof(SUBTASKS[0]);

/**
 * 三角木架 - 测试数据生成
 * 输入：一行三个整数 a b c（1 ≤ a,b,c ≤ 10000）
 * 输出：能组成三角形输出 YES，否则 NO
 * 判定：a+b>c && a+c>b && b+c>a
 */

void test(int case_num, ofstream& fout)
{
    // ============================================================
    // Subtask 0: 样例数据 — case 1-3
    // ============================================================
    if (case_num == 1) {
        fout << "3 4 5" << endl;
    }
    else if (case_num == 2) {
        fout << "1 2 3" << endl;
    }
    else if (case_num == 3) {
        fout << "5 5 9" << endl;
    }
    // ============================================================
    // Subtask 1: 小规模 + 特殊性质 — case 4-8
    // ============================================================
    else if (case_num == 4) {
        // 最小合法边界
        fout << "1 1 1" << endl;
    }
    else if (case_num == 5) {
        // 特殊：等腰三角形
        fout << "6 6 8" << endl;
    }
    else if (case_num == 6) {
        // 特殊：等边三角形
        fout << "7 7 7" << endl;
    }
    else if (case_num == 7) {
        // 特殊：直角三角形
        fout << "3 4 5" << endl;
    }
    else if (case_num == 8) {
        // 特殊：极限大，能组成
        fout << "10000 9999 2" << endl;
    }
    // ============================================================
    // Subtask 2: Hack 数据 — case 9-11
    // ============================================================
    else if (case_num == 9) {
        // Hack：两边和恰等于第三边（漏写严格大于）
        fout << "2 3 5" << endl;
    }
    else if (case_num == 10) {
        // Hack：极端差值不能组成
        fout << "10000 10000 20000" << endl;
    }
    else if (case_num == 11) {
        // Hack：一个边为最小，另两边极大
        fout << "1 10000 10000" << endl;
    }
    // ============================================================
    // Subtask 3: 中大规模 — case 12-20
    // ============================================================
    else if (case_num >= 12 && case_num <= 15) {
        // 随机，能组成（生成三边保证构成三角形）
        int a = rand() % 9000 + 1000;
        int b = rand() % 9000 + 1000;
        int c = rand() % 9000 + 1000;
        fout << a << " " << b << " " << c << endl;
    }
    else if (case_num >= 16 && case_num <= 18) {
        // 随机，大概率不能组成（大跨度）
        int a = rand() % 100 + 1;
        int b = rand() % 9000 + 1000;
        int c = rand() % 9000 + 1000;
        fout << a << " " << b << " " << c << endl;
    }
    else if (case_num == 19) {
        // 极限大，恰能组成
        fout << "9999 9999 10000" << endl;
    }
    else if (case_num == 20) {
        // 极限大，不能组成
        fout << "1 10000 10000" << endl;
    }
    // ============================================================
    // Subtask 4: 随机回归 — case 21-25
    // ============================================================
    else {
        int a = rand() % 10000 + 1;
        int b = rand() % 10000 + 1;
        int c = rand() % 10000 + 1;
        fout << a << " " << b << " " << c << endl;
    }
}

#endif
