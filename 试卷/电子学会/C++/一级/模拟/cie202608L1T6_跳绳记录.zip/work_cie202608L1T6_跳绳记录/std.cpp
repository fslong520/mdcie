#include <iostream>
using namespace std;

int main()
{
    int n, x, maxn = 0;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> x;
        if (x > maxn)
            maxn = x;
    }
    cout << maxn << endl;
    return 0;
}
