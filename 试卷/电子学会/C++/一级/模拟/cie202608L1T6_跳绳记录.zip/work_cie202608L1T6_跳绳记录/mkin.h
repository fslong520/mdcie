#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

// ═══════════════════════════════════════════════════════════════════
// 总测试点数量 & Subtask 分组配置
// ═══════════════════════════════════════════════════════════════════
const int TEST_CASES = 25;

struct SubtaskDef {
    int id, start, end;
};
const SubtaskDef SUBTASKS[] = {
    {0, 1, 2},    // 样例
    {1, 3, 8},    // 小规模 + 特殊性质
    {2, 9, 11},   // Hack 数据
    {3, 12, 20},  // 中大规模
    {4, 21, 25},  // 随机回归
};
const int SUBTASK_COUNT = sizeof(SUBTASKS) / sizeof(SUBTASKS[0]);

/**
 * 跳绳记录 - 测试数据生成
 * 输入：n（1≤n≤1000），第二行 n 个整数（1≤x≤10000）
 * 输出：n 个数中的最大值
 */

void test(int case_num, ofstream& fout)
{
    // ============================================================
    // Subtask 0: 样例数据 — case 1-2
    // ============================================================
    if (case_num == 1) {
        fout << 5 << endl;
        fout << "100 200 150 300 250" << endl;
    }
    else if (case_num == 2) {
        fout << 3 << endl;
        fout << "50 50 50" << endl;
    }
    // ============================================================
    // Subtask 1: 小规模 + 特殊性质 — case 3-8
    // ============================================================
    else if (case_num == 3) {
        // 最小 n=1
        fout << 1 << endl;
        fout << 100 << endl;
    }
    else if (case_num == 4) {
        // 小规模随机 n=10
        fout << 10 << endl;
        for (int i = 0; i < 10; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 100 + 1;
        }
        fout << endl;
    }
    else if (case_num == 5) {
        // 特殊：全相同
        fout << 8 << endl;
        for (int i = 0; i < 8; i++) {
            if (i > 0) fout << " ";
            fout << 7;
        }
        fout << endl;
    }
    else if (case_num == 6) {
        // 特殊：严格递增
        fout << 10 << endl;
        for (int i = 1; i <= 10; i++) {
            if (i > 1) fout << " ";
            fout << i;
        }
        fout << endl;
    }
    else if (case_num == 7) {
        // 特殊：严格递减
        fout << 10 << endl;
        for (int i = 10; i >= 1; i--) {
            if (i < 10) fout << " ";
            fout << i;
        }
        fout << endl;
    }
    else if (case_num == 8) {
        // 特殊：最大值在首位
        fout << 6 << endl;
        fout << "999 1 2 3 4 5" << endl;
    }
    // ============================================================
    // Subtask 2: Hack 数据 — case 9-11
    // ============================================================
    else if (case_num == 9) {
        // Hack：全 10000（最大值即上限）
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << 10000;
        }
        fout << endl;
    }
    else if (case_num == 10) {
        // Hack：n=1 且值为上限
        fout << 1 << endl;
        fout << 10000 << endl;
    }
    else if (case_num == 11) {
        // Hack：全 1（最小值，最大值=1）
        fout << 500 << endl;
        for (int i = 0; i < 500; i++) {
            if (i > 0) fout << " ";
            fout << 1;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 3: 中大规模 — case 12-20
    // ============================================================
    else if (case_num >= 12 && case_num <= 15) {
        // 中规模随机 n≈100~500
        int n = rand() % 401 + 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 10000 + 1;
        }
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 18) {
        // 大规模 n=1000
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 10000 + 1;
        }
        fout << endl;
    }
    else if (case_num == 19) {
        // 最大值在末尾
        fout << 1000 << endl;
        for (int i = 0; i < 999; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 100 + 1;
        }
        fout << " 10000" << endl;
    }
    else if (case_num == 20) {
        // 递增到上限
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << i % 10000 + 1;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 4: 随机回归 — case 21-25
    // ============================================================
    else {
        int n = rand() % 1000 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 10000 + 1;
        }
        fout << endl;
    }
}

#endif
