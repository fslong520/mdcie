#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

// ═══════════════════════════════════════════════════════════════════
// 总测试点数量 & Subtask 分组配置
// ═══════════════════════════════════════════════════════════════════
const int TEST_CASES = 25;

struct SubtaskDef {
    int id, start, end;
};
const SubtaskDef SUBTASKS[] = {
    {0, 1, 2},    // 样例
    {1, 3, 8},    // 小规模 + 特殊性质
    {2, 9, 11},   // Hack 数据
    {3, 12, 20},  // 中大规模
    {4, 21, 25},  // 随机回归
};
const int SUBTASK_COUNT = sizeof(SUBTASKS) / sizeof(SUBTASKS[0]);

/**
 * 平均成绩 - 测试数据生成
 * 输入：n（1≤n≤1000），第二行 n 个整数（0≤x≤100）
 * 输出：平均值，保留两位小数
 */

void test(int case_num, ofstream& fout)
{
    // ============================================================
    // Subtask 0: 样例数据 — case 1-2
    // ============================================================
    if (case_num == 1) {
        fout << 4 << endl;
        fout << "85 90 78 92" << endl;
    }
    else if (case_num == 2) {
        fout << 3 << endl;
        fout << "60 60 60" << endl;
    }
    // ============================================================
    // Subtask 1: 小规模 + 特殊性质 — case 3-8
    // ============================================================
    else if (case_num == 3) {
        // 最小 n=1
        fout << 1 << endl;
        fout << 100 << endl;
    }
    else if (case_num == 4) {
        // 小规模随机 n=5
        fout << 5 << endl;
        for (int i = 0; i < 5; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
    else if (case_num == 5) {
        // 特殊：全相同
        fout << 6 << endl;
        for (int i = 0; i < 6; i++) {
            if (i > 0) fout << " ";
            fout << 88;
        }
        fout << endl;
    }
    else if (case_num == 6) {
        // 特殊：严格递增
        fout << 8 << endl;
        for (int i = 1; i <= 8; i++) {
            if (i > 1) fout << " ";
            fout << i * 10;
        }
        fout << endl;
    }
    else if (case_num == 7) {
        // 特殊：严格递减
        fout << 8 << endl;
        for (int i = 8; i >= 1; i--) {
            if (i < 8) fout << " ";
            fout << i * 10;
        }
        fout << endl;
    }
    else if (case_num == 8) {
        // 特殊：总和能被 n 整除（平均为整数）
        fout << 4 << endl;
        fout << "100 100 100 100" << endl;
    }
    // ============================================================
    // Subtask 2: Hack 数据 — case 9-11
    // ============================================================
    else if (case_num == 9) {
        // Hack：除不尽，循环小数
        fout << 3 << endl;
        fout << "100 100 100" << endl;
    }
    else if (case_num == 10) {
        // Hack：n=1 且值为最小
        fout << 1 << endl;
        fout << 0 << endl;
    }
    else if (case_num == 11) {
        // Hack：混合极值
        fout << 5 << endl;
        fout << "0 100 0 100 0" << endl;
    }
    // ============================================================
    // Subtask 3: 中大规模 — case 12-20
    // ============================================================
    else if (case_num >= 12 && case_num <= 15) {
        // 中规模随机 n≈100~500
        int n = rand() % 401 + 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 18) {
        // 大规模 n=1000
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
    else if (case_num == 19) {
        // 全 100
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << 100;
        }
        fout << endl;
    }
    else if (case_num == 20) {
        // 全 0
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << 0;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 4: 随机回归 — case 21-25
    // ============================================================
    else {
        int n = rand() % 1000 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 101;
        }
        fout << endl;
    }
}

#endif
