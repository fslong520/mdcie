#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

// ═══════════════════════════════════════════════════════════════════
// 总测试点数量 & Subtask 分组配置
// ═══════════════════════════════════════════════════════════════════
const int TEST_CASES = 25;

struct SubtaskDef {
    int id, start, end;
};
const SubtaskDef SUBTASKS[] = {
    {0, 1, 2},    // 样例
    {1, 3, 8},    // 小规模 + 特殊性质
    {2, 9, 11},   // Hack 数据
    {3, 12, 20},  // 中大规模
    {4, 21, 25},  // 随机回归
};
const int SUBTASK_COUNT = sizeof(SUBTASKS) / sizeof(SUBTASKS[0]);

/**
 * 幸运兑换 - 测试数据生成
 * 输入：n, 然后n个整数
 * 输出：能被3整除的个数
 * 范围：1 ≤ n ≤ 1000, 整数绝对值 ≤ 10000
 */

void test(int case_num, ofstream& fout)
{
    // ============================================================
    // Subtask 0: 样例数据 — case 1-2
    // ============================================================
    if (case_num == 1) {
        fout << "5" << endl;
        fout << "3 6 7 9 10" << endl;
    }
    else if (case_num == 2) {
        fout << "4" << endl;
        fout << "1 2 4 5" << endl;
    }
    // ============================================================
    // Subtask 1: 小规模随机 — case 3-5
    // ============================================================
    else if (case_num >= 3 && case_num <= 5) {
        int n = rand() % 10 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 2001 - 1000;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 1(续): 特殊性质 — case 6-8
    // ============================================================
    else if (case_num == 6) {
        // 全部能被3整除
        int n = 5;
        fout << n << endl;
        fout << "3 6 9 12 15" << endl;
    }
    else if (case_num == 7) {
        // 全部不能被3整除
        int n = 5;
        fout << n << endl;
        fout << "1 2 4 5 7" << endl;
    }
    else if (case_num == 8) {
        // 包含0（0能被3整除）
        int n = 3;
        fout << n << endl;
        fout << "0 3 5" << endl;
    }
    // ============================================================
    // Subtask 2: Hack 数据 — case 9-11
    // ============================================================
    else if (case_num == 9) {
        // 负数：-3能被3整除
        int n = 3;
        fout << n << endl;
        fout << "-3 3 0" << endl;
    }
    else if (case_num == 10) {
        // n=1，边界
        int n = 1;
        fout << n << endl;
        fout << "3" << endl;
    }
    else if (case_num == 11) {
        // n=1，不整除
        int n = 1;
        fout << n << endl;
        fout << "4" << endl;
    }
    // ============================================================
    // Subtask 3: 中等规模 — case 12-15
    // ============================================================
    else if (case_num >= 12 && case_num <= 15) {
        int n = rand() % 901 + 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 20001 - 10000;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 3(续): 大规模 — case 16-20
    // ============================================================
    else if (case_num >= 16 && case_num <= 20) {
        int n = 1000;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 20001 - 10000;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 4: 随机回归 — case 21-25
    // ============================================================
    else {
        int n = rand() % 500 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 20001 - 10000;
        }
        fout << endl;
    }
}

#endif
