#include <iostream>
using namespace std;

int main()
{
    int m;
    cin >> m;
    int hour = m / 60;
    int minute = m % 60;
    cout << hour << " " << minute << endl;
    return 0;
}
