#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

// ═══════════════════════════════════════════════════════════════════
// 总测试点数量 & Subtask 分组配置
// ═══════════════════════════════════════════════════════════════════
const int TEST_CASES = 25;

struct SubtaskDef {
    int id, start, end;
};
const SubtaskDef SUBTASKS[] = {
    {0, 1, 3},    // 样例（题面 3 个样例）
    {1, 4, 8},    // 小规模 + 特殊性质
    {2, 9, 11},   // Hack 数据
    {3, 12, 20},  // 中大规模
    {4, 21, 25},  // 随机回归
};
const int SUBTASK_COUNT = sizeof(SUBTASKS) / sizeof(SUBTASKS[0]);

/**
 * 蛋糕计时 - 测试数据生成
 * 输入：一个整数 m（1 ≤ m ≤ 10000）
 * 输出：m/60 与 m%60
 */

void test(int case_num, ofstream& fout)
{
    // ============================================================
    // Subtask 0: 样例数据 — case 1-3
    // ============================================================
    if (case_num == 1) {
        fout << 125 << endl;
    }
    else if (case_num == 2) {
        fout << 90 << endl;
    }
    else if (case_num == 3) {
        fout << 45 << endl;
    }
    // ============================================================
    // Subtask 1: 小规模 + 特殊性质 — case 4-8
    // ============================================================
    else if (case_num == 4) {
        // 最小合法输入
        fout << 1 << endl;
    }
    else if (case_num == 5) {
        // 不足 1 小时
        fout << 59 << endl;
    }
    else if (case_num == 6) {
        // 恰好 1 小时
        fout << 60 << endl;
    }
    else if (case_num == 7) {
        // 整数小时
        fout << 600 << endl;
    }
    else if (case_num == 8) {
        // 小时与分钟皆最大
        fout << 3599 << endl;
    }
    // ============================================================
    // Subtask 2: Hack 数据 — case 9-11
    // ============================================================
    else if (case_num == 9) {
        // 最大合法输入，验边界
        fout << 10000 << endl;
    }
    else if (case_num == 10) {
        // 进位边界：1 小时 1 分
        fout << 61 << endl;
    }
    else if (case_num == 11) {
        // 进位边界：1 小时 59 分
        fout << 119 << endl;
    }
    // ============================================================
    // Subtask 3: 中大规模 — case 12-20
    // ============================================================
    else if (case_num >= 12 && case_num <= 15) {
        // 中规模随机 [100, 5000]
        int m = rand() % 4901 + 100;
        fout << m << endl;
    }
    else if (case_num >= 16 && case_num <= 18) {
        // 大规模随机 [5001, 10000]
        int m = rand() % 5000 + 5001;
        fout << m << endl;
    }
    else if (case_num == 19) {
        // 上限 - 1
        fout << 9999 << endl;
    }
    else if (case_num == 20) {
        // 上限压力
        fout << 10000 << endl;
    }
    // ============================================================
    // Subtask 4: 随机回归 — case 21-25
    // ============================================================
    else {
        int m = rand() % 10000 + 1;
        fout << m << endl;
    }
}

#endif
