#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

// ═══════════════════════════════════════════════════════════════════
// 总测试点数量 & Subtask 分组配置
// ═══════════════════════════════════════════════════════════════════
const int TEST_CASES = 25;

struct SubtaskDef {
    int id, start, end;
};
const SubtaskDef SUBTASKS[] = {
    {0, 1, 2},    // 样例
    {1, 3, 8},    // 小规模 + 特殊性质
    {2, 9, 11},   // Hack 数据
    {3, 12, 20},  // 中大规模
    {4, 21, 25},  // 随机回归
};
const int SUBTASK_COUNT = sizeof(SUBTASKS) / sizeof(SUBTASKS[0]);

/**
 * 买菜算账 - 测试数据生成
 * 输入：n（1 ≤ n ≤ 1000），随后 n 个价格（1 ≤ 价格 ≤ 10000）
 * 输出：n 个价格之和
 */

void test(int case_num, ofstream& fout)
{
    // ============================================================
    // Subtask 0: 样例数据 — case 1-2
    // ============================================================
    if (case_num == 1) {
        fout << 3 << endl;
        fout << "3 5 2" << endl;
    }
    else if (case_num == 2) {
        fout << 5 << endl;
        fout << "10 20 30 40 50" << endl;
    }
    // ============================================================
    // Subtask 1: 小规模 + 特殊性质 — case 3-8
    // ============================================================
    else if (case_num == 3) {
        // 最小 n
        fout << 1 << endl;
        fout << 1 << endl;
    }
    else if (case_num == 4) {
        // 小规模随机 n=5
        fout << 5 << endl;
        for (int i = 0; i < 5; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 100 + 1;
        }
        fout << endl;
    }
    else if (case_num == 5) {
        // 小规模随机 n=10
        fout << 10 << endl;
        for (int i = 0; i < 10; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 100 + 1;
        }
        fout << endl;
    }
    else if (case_num == 6) {
        // 特殊：全相同值
        fout << 6 << endl;
        fout << "7 7 7 7 7 7" << endl;
    }
    else if (case_num == 7) {
        // 特殊：递增序列
        fout << 8 << endl;
        for (int i = 1; i <= 8; i++) {
            if (i > 1) fout << " ";
            fout << i;
        }
        fout << endl;
    }
    else if (case_num == 8) {
        // 特殊：递减序列
        fout << 8 << endl;
        for (int i = 8; i >= 1; i--) {
            if (i < 8) fout << " ";
            fout << i;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 2: Hack 数据 — case 9-11
    // ============================================================
    else if (case_num == 9) {
        // Hack：n=1 单元素边界
        fout << 1 << endl;
        fout << 10000 << endl;
    }
    else if (case_num == 10) {
        // Hack：全 10000，n=1000，验 int 求和
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << 10000;
        }
        fout << endl;
    }
    else if (case_num == 11) {
        // Hack：混合极值与大值，验累加正确
        fout << 500 << endl;
        for (int i = 0; i < 500; i++) {
            if (i > 0) fout << " ";
            fout << (i % 2 == 0 ? 1 : 10000);
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 3: 中大规模 — case 12-20
    // ============================================================
    else if (case_num >= 12 && case_num <= 15) {
        // 中规模随机 [100, 500]
        int n = rand() % 401 + 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 10000 + 1;
        }
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 18) {
        // 大规模随机 n=1000
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 10000 + 1;
        }
        fout << endl;
    }
    else if (case_num == 19) {
        // 全 1，n=1000
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << 1;
        }
        fout << endl;
    }
    else if (case_num == 20) {
        // 递增到上限，n=1000
        fout << 1000 << endl;
        for (int i = 0; i < 1000; i++) {
            if (i > 0) fout << " ";
            fout << i % 10000 + 1;
        }
        fout << endl;
    }
    // ============================================================
    // Subtask 4: 随机回归 — case 21-25
    // ============================================================
    else {
        int n = rand() % 1000 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            if (i > 0) fout << " ";
            fout << rand() % 10000 + 1;
        }
        fout << endl;
    }
}

#endif
